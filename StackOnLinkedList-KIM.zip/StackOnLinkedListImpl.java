package edu.ensign.cs335.structure.stack;public class StackOnLinkedListImpl {
}

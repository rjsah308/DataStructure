package CS335Arrays;

import java.util.Random;

public class ArrayIteration2 {

	public static void main(String[] args) {

		long start;
		long finish;
		long eTime; //Declare variables

		start = System.currentTimeMillis(); //Start to set time
		Integer[] sequenceResults = sequenceNum(); //Declare Array
		finish = System.currentTimeMillis(); //End to set time
		eTime = finish - start; //Calculate
		print(sequenceResults, eTime, 0); //Print method

		start = System.currentTimeMillis();
		Integer[] randomResults = randomNum(1, 100000);
		finish = System.currentTimeMillis();
		eTime = finish - start;
		print(randomResults, eTime, 1);
	}
	//Make sequential Number in the Array
	public static Integer[] sequenceNum() {
		Integer[] result = new Integer[100]; // Declare 100 size of he array
		for (int i = 0; i < 100; i++) {
			result[i] = i + 1;
		}
		return result;
	}
	//Make Positive Random Number in the Array
	public static Integer[] randomNum(int start, int end) {
		Integer[] result = new Integer[100]; // Declare 100 size of he array
		Random random = new Random();
		for (int i = 0; i < 100; i++) {
			int randomValue = random.nextInt(end - start + 1) + start;
			result[i] = randomValue;
		}
		return result;
	}
	//Help to print out the results
	//parameter: 1. Array in the above, 2. calculated elapsed time, 3. To identify Random or Sequence
	public static void print(Integer[] numbers, long t, int x) {
		System.out.println("Elapsed Time in ms: " + t + "\n");
		if (x == 0) {
			System.out.println("Dumping the content of 'my_sequential_numbers' array: Size = " + numbers.length + "\n");
		} else {
			System.out.println("Dumping the content of 'my_random_numbers' array: Size = " + numbers.length + "\n");
		}
		for (int i = 0; i < numbers.length; i++) {
			System.out.print(numbers[i] + " ");//Shows the array elements
		}
		System.out.println("Displaying all the elements of the Array:");
		System.out.println("Done...\n\n");
	}//Print elements
}
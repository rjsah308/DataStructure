package CS335Arrays;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ArrayIteration {

	public static void main(String[] args) {

		List<Integer> sequenceResults = sequenceNum(1, 100);
		for (int i = 0; i < 100; i++) {
			System.out.print(sequenceResults.get(i) + " ");
		}
		System.out.println("\nsequenceNum size is : " + sequenceResults.size());
		System.out.print("\n\n");
		List<Integer> randomResults = randomNum(1, 100000);
		for (int i = 0; i < 100; i++) {
			System.out.print(randomResults.get(i) + " ");
		}
		System.out.println("\nrandomNum size is : " + randomResults.size());
	}

	public static List<Integer> sequenceNum(int start, int end) {
		List<Integer> result = new ArrayList<>(100);
		for (int i = 1; i <= 100; i++) {
			result.add(i);
		}
		return result;
	}

	public static List<Integer> randomNum(int start, int end) {
		List<Integer> result = new ArrayList<>(100);
		Random random = new Random();
		for (int i = 1; i <= 100; i++) {
			int randomValue = random.nextInt(end - start + 1) + start;
			result.add(randomValue);
		}
		return result;
	}
}
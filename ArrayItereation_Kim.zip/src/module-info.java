module ArrayItereation_Kim {
}